/*
 * SPDX-FileCopyrightText: This file has no copyright assigned and is placed in the Public Domain.
 * SPDX-License-Identifier: CC0-1.0
 *
 * This file is part of the w64 mingw-runtime package.
 * No warranty is given; refer to https://github.com/kinke/mingw-w64-crt/blob/master/DISCLAIMER.PD.
 */

typedef interface IProcessorArchitecture IProcessorArchitecture;
